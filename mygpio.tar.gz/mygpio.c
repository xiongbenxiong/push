
#define  MYGPIO_START_CMD    _IO('K', 1)
#include <linux/module.h>
#include <linux/types.h>
#include <linux/fs.h>
#include <linux/errno.h>
#include <linux/mm.h>
#include <linux/sched.h>
#include <linux/init.h>
#include <linux/cdev.h>
#include <asm/io.h>
#include <asm/system.h>
#include <asm/uaccess.h>
#include <mach/regs-gpio.h>
#include <mach/hardware.h>
#include <linux/gpio.h>
#include <linux/ioctl.h>
#include <linux/kernel.h>
#include <linux/interrupt.h>
#include <linux/irq.h>
#include <linux/spinlock.h>
//#include <linux/list.h>
#include <linux/device.h>
#include <linux/err.h>
#include <linux/seq_file.h>
#include <linux/of_gpio.h>
#include <linux/idr.h>
#include <linux/slab.h>

#define CREATE_TRACE_POINTS
#include <trace/events/gpio.h>


#define  MYGPIO_MAJOR 243    /*预设的mygpio的主设备号*/

#define  MYGPIO_START_CMD    _IO('k', 1)
#define  MYGPIO_STOP_CMD     _IO('K', 0)

MODULE_LICENSE("Dual BSD/GPL");

static int mygpio_major = MYGPIO_MAJOR;
static struct  cdev  MygpioDev;

/////////////////////////////////////////////////////
void mygpio_start(void)//gpio_set_value(1)
{
   // set GPB0 as high
}

/*mygpio start*/
void mygpio_stop(void)//gpio_set_value(0)
{
   // set GPB0 as low
}


/*文件打开函数*///////////////加入数据
int mygpio_open(struct inode *inode, struct file *filp)
{
  // s3c2410_gpio_pullup(S3C2410_GPB(0),  1);
   //set GPB0 as output
 //  s3c2410_gpio_cfgpin(S3C2410_GPB(0),  S3C2410_GPIO_OUTPUT);
  return 0;
}

/*文件释放函数*/
int mygpio_release(struct inode *inode, struct file *filp)
{
  return 0;
}

/* ioctl设备控制函数 */
static int mygpio_ioctl(struct inode *inode, struct file *filp, unsigned  int cmd, unsigned long arg)
{
  return 0;
}
static const DEVICE_ATTR(value, 0644,mygpio_read, mygpio_write);

/*读函数*/
static ssize_t mygpio_read(struct file *filp, char __user *buf, size_t size, loff_t *offt)
{
  return 0;
}

/*写函数*/////////////////加入数据
static ssize_t mygpio_write(struct device *dev,struct device_attribute *attr, const char *buf,
  size_t size)
{
	printk("->>>>>>>>>>%s\n",__func__);
	struct gpio_desc        *desc = dev_get_drvdata(dev);
	ssize_t                 status;

	mutex_lock(&sysfs_lock);

	if (!test_bit(FLAG_EXPORT, &desc->flags))
		status = -EIO;
	else if (!test_bit(FLAG_IS_OUT, &desc->flags))
		status = -EPERM;
	else {
		long            value;

		status = strict_strtol(buf, 0, &value);
		if (status == 0) {
			if (test_bit(FLAG_ACTIVE_LOW, &desc->flags))
				value = !value;
			gpiod_set_value_cansleep(desc, value != 0);
			status = size;
		}
	}

	mutex_unlock(&sysfs_lock);
	return status;
}

/*文件操作结构体*/
static struct file_operations mygpio_remap_fops =
{
  .owner = THIS_MODULE,
  .read = mygpio_read,
  .write = mygpio_write,
  .ioctl = mygpio_ioctl,
  .open = mygpio_open,
  .release = mygpio_release,
};

/*初始化并注册cdev*/
static void mygpio_setup_cdev(struct cdev *dev,  int minor,  struct  file_operations  *fops)
{
  int err, devno = MKDEV(mygpio_major, minor);

  cdev_init(dev, fops);
  dev->owner = THIS_MODULE;
  dev->ops = fops;
  err = cdev_add(dev, devno, 1);
  if (err)
    printk(KERN_NOTICE "Error %d adding LED%d", err, minor);
}

/*设备驱动模块加载函数*/
int mygpio_init(void)
{
  int result;
  dev_t devno = MKDEV(mygpio_major, 0);

  /* 申请设备号*/
  if (mygpio_major)
    result = register_chrdev_region(devno, 1, "pan_mygpio");
  else  /* 动态申请设备号 */
   {
    result = alloc_chrdev_region(&devno, 0, 1, "pan_mygpio");
    mygpio_major = MAJOR(devno);
   }  
  if (result < 0)
   {
    printk(KERN_WARNING"mygpio: unable to get major %d\n", mygpio_major);
    return result;
   }
  mygpio_setup_cdev(&BeepDev, 0,  &mygpio_remap_fops);
  printk("mygpio device installed, with major %d\n", mygpio_major);
  return   0;
}

/*模块卸载函数*/
void mygpio_exit(void)
{
  cdev_del(&BeepDev);   /*注销cdev*/
  unregister_chrdev_region(MKDEV(mygpio_major, 0), 1); /*释放设备号*/
  printk("mygpio device uninstalled\n");
}

MODULE_AUTHOR("xxxxxxxxx");

EXPORT_SYMBOL(mygpio_major);
module_init(mygpio_init);
module_exit(mygpio_exit);
