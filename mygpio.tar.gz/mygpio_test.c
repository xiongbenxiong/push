#include <stdio.h>
#include <fcntl.h>
#include <linux/ioctl.h>
#include<stdlib.h>
#include<unistd.h>

#define  MYGPIO_START_CMD    _IO('K', 1)
#define  MYGPIO_STOP_CMD     _IO('K', 0)

int main(void)
{
	int mygpio_fd;
	int ret;
	mygpio_fd = open("/dev/mygpio", O_RDONLY | O_NONBLOCK);
	if(mygpio_fd!=-1)
	{
		printf("the mygpio_fd is %d\n",mygpio_fd);

	}
	else
	{
		printf("cannot open file /dev/mygpio\n");
		exit(1);
	}
	while(1)
	{
		ioctl(mygpio_fd, MYGPIO_START_CMD, 0);
		usleep(1000);
		ioctl(mygpio_fd,MYGPIO_STOP_CMD,0);
		usleep(5000);
	}
	close(mygpio_fd);
	return 0;
}    
